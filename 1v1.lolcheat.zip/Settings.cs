﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RPN_Mods
{
    public static class ESPSettings
    {
        public static Color BoxColor = Color.green;
        public static bool BoxRainbow = false;

        public static Color SkeletonColor = Color.cyan;
        public static bool SkeletonRainbow = false;

        public static Color CharmColor = Color.magenta;
        public static bool CharmRainbow = true;
    }

    public static class Configs
    {
        public static bool aimbot = false;
        public static float smooth = 5f;
        public static bool silentaim = false;
        public static float fov = 180;
        public static bool fovcircle = false;

        public static bool godmode = false;

        public static bool infiniteammo = false;

        public static bool rapidfire = false;
        public static int rapidcooldown = 0;
        public static float fireratecooldown = 3;
        public static float rapidfireMultiplier = 3;

        public static bool Noreload = false;
        public static float ReloadSpeedModifier = 5;
        public static float NoReloadMultiplier = 5;

        public static bool NoRecoil = false;
        public static float RecoilSpeedModifier = 0;
        public static float NoRecoilMultiplier = 0;

        public static bool crasher = false;

        public static bool boxesp = false;
        public static bool filledboxesp = false;
        public static bool boxfix = false;
        public static bool charmESP = false;

        public static bool speed = false;
        public static float speedmultiply = 5;

        public static bool WinGame = false;
        public static bool DestoryAllBuild = false;
        public static bool fly = false;
        public static bool Weaponlevel = false;
        public static bool infinitemats = false;
        public static bool nodive = false;
        public static bool snaplines = false;
        public static bool onetap = false;
        public static bool openallCreates = false;
        public static bool UnlockallStickers = false;
        public static bool UnlockallEmotes = false;
        public static bool UnlockallSkins = false;
        public static bool UnlockAllWeapons = false;
        public static bool Killall = false;
        public static bool SpawnAllGuns = false;
        public static bool snowngun = false;
        public static bool explosiongun = false;
    }
}
