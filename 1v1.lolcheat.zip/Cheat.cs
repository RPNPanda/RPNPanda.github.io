﻿using Assets.Scripts;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using UnityEngine;

namespace RPN_Mods
{
    public class Cheat : MonoBehaviour
    {
        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        public int toggleKey = 45;
        public float toggleDelay = 0.5f;
        private bool toggled = true;
        private float lastToggleTime;

        private static Material espMat = new Material(Shader.Find("GUI/Text Shader"));
        private static Material charmMat = new Material(Shader.Find("GUI/Text Shader"));
        public static Material mat = new Material(Shader.Find("GUI/Text Shader"));
        private static Material lrMatWhite;
        private static Material lrMatBlack;

        private float colorChangeSpeed = 1f;
        private float timer = 0f;

        private void Start()
        {
            StartCoroutine(UpdateTargets());
            if (lrMatWhite == null)
            {
                lrMatWhite = new Material(Shader.Find("GUI/Text Shader")) { color = Color.white };
            }
            if (lrMatBlack == null)
            {
                lrMatBlack = new Material(Shader.Find("GUI/Text Shader")) { color = Color.black };
            }

        }

        private IEnumerator UpdateTargets()
        {
            while (true)
            {
                yield return new WaitForSeconds(1f);
            }
        }

        private void OnGUI()
        {
            float r = Mathf.PingPong(timer * colorChangeSpeed, 1f);
            float g = Mathf.PingPong(timer * colorChangeSpeed + 0.33f, 1f);
            float b = Mathf.PingPong(timer * colorChangeSpeed + 0.66f, 1f);

            UnityEngine.GUI.color = new Color(r, g, b);

            UnityEngine.GUI.Label(new Rect(10, 10, 400, 40), "RPN Mods 1v1.lol Cheat");

            UnityEngine.GUI.color = Color.white;

            timer += Time.deltaTime;

            if (toggled)
            {
                GUI.GUIRect = UnityEngine.GUI.Window(69, GUI.GUIRect, GUI.GUIMain, "\"RPN Mods 1v1.lol Cheat | FPS: " + 1.0f / Time.deltaTime + " | Toggle: INSERT");
            }
        }

        private void GUIToggleCheck()
        {
            if (GetAsyncKeyState(toggleKey) < 0)
            {
                if (Time.time - lastToggleTime >= toggleDelay)
                {
                    toggled = !toggled;
                    lastToggleTime = Time.time;
                }
            }
        }
    }
}
