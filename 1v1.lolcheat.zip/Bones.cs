﻿using System.Linq;
using UnityEngine;

namespace RPN_Mods
{
    public static class Bones
    {
        public struct Conn
        {
            public int A;
            public int B;
            public string Id;
            public Conn(int a, int b)
            {
                A = a; B = b; Id = $"bone_{a}_{b}";
            }
        }

        public static readonly Conn[] Connections = new Conn[]
        {
            new Conn(0, 7),
            new Conn(7, 8),
            new Conn(8, 9),
            new Conn(9, 10),

            new Conn(8, 11),
            new Conn(11, 13),
            new Conn(13, 15),
            new Conn(15, 17),

            new Conn(8, 12),
            new Conn(12, 14),
            new Conn(14, 16),
            new Conn(16, 18),

            new Conn(0, 1),
            new Conn(1, 3),
            new Conn(3, 5),

            new Conn(0, 2),
            new Conn(2, 4),
            new Conn(4, 6),
        };

        public static readonly int[] UniqueBoneIds =
            Connections.SelectMany(c => new[] { c.A, c.B }).Distinct().ToArray();
    }
}
