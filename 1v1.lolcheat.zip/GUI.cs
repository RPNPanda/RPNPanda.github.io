﻿using UnityEngine;

namespace RPN_Mods
{
    public class GUI : MonoBehaviour
    {
        public static Rect GUIRect = new Rect(30, 30, 500, 300);
        public static int selected_tab = 0;
        private static string[] tabnames = { "Aimbot", "ESP", "Exploits", "World" };
        public static Vector2 scrollPosition = Vector2.zero;
        private static float applyButtonTimer = 0f;

        public Material blackMat;
        private static Texture2D _buttonTexture;
        private static Texture2D ButtonTexture
        {
            get
            {
                if (_buttonTexture == null)
                {
                    _buttonTexture = new Texture2D(1, 1);
                    _buttonTexture.SetPixel(0, 0, Color.white);
                    _buttonTexture.Apply();
                }
                return _buttonTexture;
            }
        }

        private static Texture2D _tabTexture;
        private static Texture2D TabTexture
        {
            get
            {
                if (_tabTexture == null)
                {
                    _tabTexture = new Texture2D(1, 1);
                    _tabTexture.SetPixel(0, 0, new Color(0.2f, 0.2f, 0.2f));
                    _tabTexture.Apply();
                }
                return _tabTexture;
            }
        }

        private static Texture2D _ativeTabTexture;

        private static Texture2D ativeTabTexture
        {
            get
            {
                if (_ativeTabTexture == null)
                {
                    _ativeTabTexture = new Texture2D(1, 1);
                    _ativeTabTexture.SetPixel(0, 0, new Color(0.39f, 0.39f, 0.39f));
                    _ativeTabTexture.Apply();
                }
                return _ativeTabTexture;
            }
        }
        public static Color color { get; set; }

        public static void GUIMain(int o)
        {
            Color oldColor = UnityEngine.GUI.color;
            UnityEngine.GUI.color = Color.black;
            UnityEngine.GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
            UnityEngine.GUI.color = oldColor;

            Rect backgroundRect = new Rect(10, 40, GUIRect.width - 20, GUIRect.height - 50);

            float borderThickness = 3f;

            UnityEngine.GUI.color = RainbowColor(0.5f);
            UnityEngine.GUI.DrawTexture(new Rect(backgroundRect.xMin - borderThickness, backgroundRect.yMin - borderThickness, backgroundRect.width + borderThickness * 2, borderThickness), Texture2D.whiteTexture);
            UnityEngine.GUI.DrawTexture(new Rect(backgroundRect.xMin - borderThickness, backgroundRect.yMax, backgroundRect.width + borderThickness * 2, borderThickness), Texture2D.whiteTexture);
            UnityEngine.GUI.DrawTexture(new Rect(backgroundRect.xMin - borderThickness, backgroundRect.yMin - borderThickness, borderThickness, backgroundRect.height + borderThickness * 2), Texture2D.whiteTexture);
            UnityEngine.GUI.DrawTexture(new Rect(backgroundRect.xMax, backgroundRect.yMin - borderThickness, borderThickness, backgroundRect.height + borderThickness * 2), Texture2D.whiteTexture);
            UnityEngine.GUI.color = oldColor;

            UnityEngine.GUI.color = new Color(0.05f, 0.05f, 0.05f, 1f);
            UnityEngine.GUI.Box(backgroundRect, "");
            UnityEngine.GUI.color = oldColor;

            string title = $"RPN Mods Cheat | FPS: {(1.0f / Time.deltaTime):0} | Toggle: INSERT";
            GUIStyle titleStyle = new GUIStyle(UnityEngine.GUI.skin.label);
            titleStyle.fontSize = 16;
            titleStyle.normal.textColor = Color.white;
            titleStyle.alignment = TextAnchor.MiddleCenter;

            Rect titleRect = new Rect(backgroundRect.x, backgroundRect.y - 25, backgroundRect.width, 20);
            UnityEngine.GUI.Label(titleRect, title, titleStyle);
            GUILayout.BeginArea(backgroundRect);
            scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(GUIRect.width - 20), GUILayout.Height(GUIRect.height - 50));

            GUILayout.Space(10);
            GUILayout.BeginHorizontal();

            for (int i = 0; i < tabnames.Length; i++)
            {
                Color tabColor = (selected_tab == i) ? new Color(0.29f, 0.29f, 0.29f) : new Color(0.2f, 0.2f, 0.2f);
                GUI.color = tabColor;

                GUIStyle tabStyle = new GUIStyle(UnityEngine.GUI.skin.button);
                tabStyle.normal.background = TabTexture;
                tabStyle.hover.background = ativeTabTexture;
                tabStyle.active.background = ativeTabTexture;
                tabStyle.normal.textColor = Color.white;
                tabStyle.hover.textColor = Color.white;
                tabStyle.active.textColor = Color.white;
                tabStyle.alignment = TextAnchor.MiddleCenter;

                if (GUILayout.Button(tabnames[i], tabStyle))
                    selected_tab = i;

                GUI.color = oldColor;
            }

            GUILayout.EndHorizontal();
            GUILayout.Space(10);

            switch (selected_tab)
            {
                case 0:
                    Configs.silentaim = DrawToggleCheckbox(Configs.silentaim, "Silent Aim");
                    Configs.crasher = DrawToggleCheckbox(Configs.crasher, "Crash Players in FOV Circle (Middle mouse click)");
                    break;
                case 1:
                    Configs.boxesp = DrawToggleCheckbox(Configs.boxesp, "Box ESP");
                    Configs.filledboxesp = DrawToggleCheckbox(Configs.filledboxesp, "Skeleton ESP");
                    Configs.snaplines = DrawToggleCheckbox(Configs.snaplines, "Snaplines");
                    Configs.charmESP = DrawToggleCheckbox(Configs.charmESP, "ESP Charms");
                    Configs.fovcircle = DrawToggleCheckbox(Configs.fovcircle, "FOV Circle");
                    GUILayout.Label("FOV: " + Configs.fov);
                    Configs.fov = CustomSlider(Configs.fov, 1.0f, 1440.0f);
                    break;
                case 2:
                    Configs.godmode = DrawToggleCheckbox(Configs.godmode, "God Mode");
                    Configs.infiniteammo = DrawToggleCheckbox(Configs.infiniteammo, "Infinite Ammo");
                    Configs.rapidfire = DrawToggleCheckbox(Configs.rapidfire, "Fire Rate");
                    GUILayout.Label("Fire rate cooldown: " + Configs.rapidfireMultiplier.ToString("0.0"));
                    Configs.rapidfireMultiplier = CustomSlider(Configs.rapidfireMultiplier, 1.1f, 100.0f);
                    Configs.speed = DrawToggleCheckbox(Configs.speed, "Speed");
                    GUILayout.Label("Speed: " + Configs.speedmultiply);
                    Configs.speedmultiply = CustomSlider(Configs.speedmultiply, 1.0f, 15.0f);
                    Configs.Noreload = DrawToggleCheckbox(Configs.Noreload, "Reload Rate");
                    GUILayout.Label("Reload Rate cooldown: " + Configs.NoReloadMultiplier.ToString("0.0"));
                    Configs.NoReloadMultiplier = CustomSlider(Configs.NoReloadMultiplier, 1.1f, 100.0f);
                    Configs.NoRecoil = DrawToggleCheckbox(Configs.NoRecoil, "NoRecoil");
                    Configs.fly = DrawToggleCheckbox(Configs.fly, "Fly");
                    Configs.Weaponlevel = DrawToggleCheckbox(Configs.Weaponlevel, "Max weapon Level");
                    Configs.infinitemats = DrawToggleCheckbox(Configs.infinitemats, "Infinite Mats");
                    Configs.nodive = DrawToggleCheckbox(Configs.nodive, "No Dive");
                    Configs.Killall = DrawToggleCheckbox(Configs.Killall, "Kill All");
                    Configs.snowngun = DrawToggleCheckbox(Configs.snowngun, "Snow Gun");
                    Configs.explosiongun = DrawToggleCheckbox(Configs.explosiongun, "Explosion Gun");
                    break;
                case 3:
                    Configs.DestoryAllBuild = DrawToggleCheckbox(Configs.DestoryAllBuild, "Destory All Builds");
                    Configs.WinGame = DrawToggleCheckbox(Configs.WinGame, "Win the Game");
                    Configs.onetap = DrawToggleCheckbox(Configs.onetap, "One Tap Buildings");
                    Configs.SpawnAllGuns = DrawApplyButton(Configs.SpawnAllGuns, "spawn (Almost) All Weapons");
                    Configs.openallCreates = DrawApplyButton(Configs.openallCreates, "Open All Weapon Creates");
                    GUILayout.Space(5);
                    GUILayout.Label("Unlocks:");
                    GUILayout.Label("MUST CLICK IN GAME!");
                    Configs.UnlockallStickers = DrawApplyButton(Configs.UnlockallStickers, "Unlock All Stickers");
                    Configs.UnlockallEmotes = DrawApplyButton(Configs.UnlockallEmotes, "Unlock All Emotes");
                    Configs.UnlockallSkins = DrawApplyButton(Configs.UnlockallSkins, "Unlock All Skins");
                    Configs.UnlockAllWeapons = DrawApplyButton(Configs.UnlockAllWeapons, "Unlock (Almost) All Weapons");

                    break;
            }

            GUILayout.EndScrollView();
            GUILayout.EndArea();
            UnityEngine.GUI.DragWindow(new Rect(0, 0, GUIRect.width, 20));
        }


        public static bool DrawToggleCheckbox(bool currentState, string label)
        {
            Color checkboxColor = currentState ? Color.green : Color.red;

            Color oldColor = UnityEngine.GUI.color;
            UnityEngine.GUI.color = checkboxColor;

            GUIStyle checkboxStyle = new GUIStyle(UnityEngine.GUI.skin.button)
            {
                normal = { background = ButtonTexture },
                hover = { background = ButtonTexture },
                active = { background = ButtonTexture },
                fixedWidth = 20,
                fixedHeight = 20
            };

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("", checkboxStyle))
            {
                currentState = !currentState;   
            }
            UnityEngine.GUI.color = oldColor;     

            GUILayout.Label(label, new GUIStyle(UnityEngine.GUI.skin.label) { normal = { textColor = Color.white } });
            GUILayout.EndHorizontal();

            return currentState;
        }

        public static bool DrawApplyButton(bool currentState, string label)
        {
            Color oldColor = UnityEngine.GUI.color;

            UnityEngine.GUI.color = applyButtonTimer > 0 ? new Color(0.2f, 0.2f, 0.2f) : new Color(0.2f, 0.2f, 0.2f);

            GUIStyle buttonStyle = new GUIStyle(UnityEngine.GUI.skin.button)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 14
            };

            if (GUILayout.Button(label, buttonStyle, GUILayout.Height(25)))
            {
                currentState = true;          
                applyButtonTimer = 5f;       
            }

            Rect lastRect = GUILayoutUtility.GetLastRect();
            UnityEngine.GUI.color = Color.white;
            UnityEngine.GUI.Label(lastRect, label, buttonStyle);

            if (applyButtonTimer > 0)
            {
                applyButtonTimer -= Time.deltaTime;
                if (applyButtonTimer <= 0)
                {
                    applyButtonTimer = 0;
                    currentState = false;      
                }
            }

            UnityEngine.GUI.color = oldColor;

            return currentState;
        }


        private static float CustomSlider(float value, float min, float max, params GUILayoutOption[] options)
        {
            Color oldColor = GUI.color;

            GUI.color = new Color(0.25f, 0.25f, 0.25f);   
            GUIStyle trackStyle = new GUIStyle(UnityEngine.GUI.skin.horizontalSlider);
            trackStyle.fixedHeight = 10;

            GUI.color = Color.white;
            GUIStyle thumbStyle = new GUIStyle(UnityEngine.GUI.skin.horizontalSliderThumb);
            thumbStyle.fixedWidth = 14;
            thumbStyle.fixedHeight = 14;

            float result = GUILayout.HorizontalSlider(value, min, max, trackStyle, thumbStyle, options);

            GUI.color = oldColor;

            return result;
        }


        private static Color RGBSlider(string label, Color c)
        {
            GUILayout.Label(label);
            c.r = CustomSlider(c.r, 0f, 1f);
            c.g = CustomSlider(c.g, 0f, 1f);
            c.b = CustomSlider(c.b, 0f, 1f);
            return c;
        }

        public static Color RainbowColor(float speed = 1f)
        {
            float t = Time.time * speed;
            return Color.HSVToRGB(t % 1f, 1f, 1f);      
        }

    }
}
