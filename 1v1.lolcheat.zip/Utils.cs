﻿using System.Collections.Generic;
using UnityEngine;

namespace RPN_Mods
{
    public class Utils : MonoBehaviour
    {

    }
}
